#ifndef _H5constants_H
#define _H5constants_H

#include <R.h>
#include <Rdefines.h>
#include <R_ext/Rdynload.h>
#include <R_ext/Error.h>
#include "myhdf5.h"

SEXP _H5constants();

#endif
